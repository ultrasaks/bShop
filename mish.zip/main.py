import sys
from PyQt5 import QtWidgets
from PyQt5.QtCore import QObject, QThread, pyqtSignal
#from PyQt5 import QtCore
import design
#from qt_material import apply_stylesheet
import time

class Worker(QObject):
    finished = pyqtSignal()
    progress = pyqtSignal(int)

    def stop(self):
        self.active = False
        self.wait()

    def run(self):
        self.active = True
        value = 0
        oldtime = time.time()
        while value < 100 and self.active:
            if time.time() > oldtime:
                value += 1
                self.progress.emit(value)
                oldtime = time.time() + 1
        self.finished.emit()

class ExampleApp(QtWidgets.QMainWindow, design.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.btnBrowse.clicked.connect(self.test)
        self.btnBrowse.clicked.connect(self.progr)
        self.clearBtn.clicked.connect(self.zero)

    def test(self):
        self.label.setText(self.lineEdit.text())

    def zero(self):
        if 'worker' in dir(self):
            self.worker.active = False
        self.progressBar.setValue(0)

    def reportProgress(self, progress):
        self.progressBar.setValue(progress)

    def end_progr(self):
        self.btnBrowse.setEnabled(True)

    def progr(self):
        self.btnBrowse.setEnabled(False)
        self.thread = QThread()
        self.worker = Worker()
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.worker.finished.connect(self.end_progr)
        self.thread.finished.connect(self.thread.deleteLater)
        self.worker.progress.connect(self.reportProgress)
        self.thread.start()


class Test(QtWidgets.QMainWindow, design.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.btnBrowse.clicked.connect(self.test)
        self.btnBrowse.clicked.connect(self.progr)
        self.clearBtn.clicked.connect(self.zero)



def main():
    app = QtWidgets.QApplication(sys.argv)
    window = ExampleApp()
#apply_stylesheet(app, theme='dark_blue.xml')

    window.show() 
    app.exec_()

if __name__ == '__main__':
    main()